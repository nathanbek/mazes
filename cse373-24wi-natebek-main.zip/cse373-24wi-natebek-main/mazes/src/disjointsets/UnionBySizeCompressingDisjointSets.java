package disjointsets;

import java.util.ArrayList;
import java.util.List;

/**
 * A quick-union-by-size data structure with path compression.
 * @see DisjointSets for more documentation.
 */
public class UnionBySizeCompressingDisjointSets<T> implements DisjointSets<T> {
    // Do NOT rename or delete this field. We will be inspecting it directly in our private tests.
    List<Integer> pointers;

    /*
    However, feel free to add more fields and private helper methods. You will probably need to
    add one or two more fields in order to successfully implement this class.
    */

    // Stores the size of each set
    private final List<Integer> sizes;

    // Maps each item to its index in the disjoint set
    private final List<T> items;

    public UnionBySizeCompressingDisjointSets() {
        pointers = new ArrayList<>();
        sizes = new ArrayList<>();
        items = new ArrayList<>();
    }

    @Override
    public void makeSet(T item) {
        int index = pointers.size();
        pointers.add(index);
        sizes.add(1); // Initially each set has size 1
        items.add(item); // Store the item
    }

    @Override
    public int findSet(T item) {
        int index = items.indexOf(item);
        if (index == -1) {
            throw new IllegalArgumentException("Item not found");
        }
        return findSetIndex(index);
    }

    // Recursively finds the root index of the set containing the given index
    private int findSetIndex(int index) {
        if (index != pointers.get(index)) {
            pointers.set(index, findSetIndex(pointers.get(index))); // Path compression
        }
        return pointers.get(index);
    }

    @Override
    public boolean union(T item1, T item2) {
        int index1 = findSet(item1);
        int index2 = findSet(item2);
        if (index1 == index2) {
            return false; // They are already in the same set
        }
        // Union by size: merge the smaller set into the larger one
        if (sizes.get(index1) < sizes.get(index2)) {
            pointers.set(index1, index2);
            sizes.set(index2, sizes.get(index1) + sizes.get(index2));
        } else {
            pointers.set(index2, index1);
            sizes.set(index1, sizes.get(index1) + sizes.get(index2));
        }
        return true;
    }
}
