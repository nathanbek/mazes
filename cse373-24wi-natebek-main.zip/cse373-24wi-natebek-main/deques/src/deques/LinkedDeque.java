package deques;

public class LinkedDeque<T> extends AbstractDeque<T> {
    private int size;
    Node<T> front;
    Node<T> back;

    public LinkedDeque() {
        size = 0;
        front = new Node<>(null);
        back = new Node<>(null, front, null);
        front.next = back;
    }

    public void addFirst(T item) {
        Node<T> newNode = new Node<>(item, front, front.next);
        front.next.prev = newNode;
        front.next = newNode;
        size++;
    }

    public void addLast(T item) {
        Node<T> newNode = new Node<>(item, back.prev, back);
        back.prev.next = newNode;
        back.prev = newNode;
        size++;
    }

    public T removeFirst() {
        if (size == 0) {
            return null;
        }
        Node<T> firstNode = front.next;
        T item = firstNode.value;
        front.next = firstNode.next;
        firstNode.next.prev = front;
        size--;
        return item;
    }

    public T removeLast() {
        if (size == 0) {
            return null;
        }
        Node<T> lastNode = back.prev;
        T item = lastNode.value;
        back.prev = lastNode.prev;
        lastNode.prev.next = back;
        size--;
        return item;
    }

    public T get(int index) {
        if (index < 0 || index >= size) {
            return null;
        }

        Node<T> current;

        if (index < size / 2) {
            current = front.next;
            for (int i = 0; i < index; i++) {
                current = current.next;
            }
        } else {
            current = back.prev;
            for (int i = size - 1; i > index; i--) {
                current = current.prev;
            }
        }

        return current.value;
    }

    public int size() {
        return size;
    }
}
