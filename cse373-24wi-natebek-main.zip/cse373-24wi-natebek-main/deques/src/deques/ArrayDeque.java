package deques;

@SuppressWarnings("unchecked")
public class ArrayDeque<T> extends AbstractDeque<T> {
    private T[] data;
    private int front;
    private int back;
    private int size;

    public ArrayDeque() {
        data = (T[]) new Object[8];
        front = 0;
        back = 0;
        size = 0;
    }

    private static int increment(int i, int length) {
        if (i == length - 1) {
            return 0;
        } else {
            return i + 1;
        }
    }

    private static int decrement(int i, int length) {
        if (i == 0) {
            return length - 1;
        } else {
            return i - 1;
        }
    }

    @Override
    public void addFirst(T item) {
        if (size == data.length) {
            resize(data.length * 2);
        }
        front = decrement(front, data.length);
        data[front] = item;
        size++;
    }

    @Override
    public void addLast(T item) {
        if (size == data.length) {
            resize(data.length * 2);
        }
        data[back] = item;
        back = increment(back, data.length);
        size++;
    }

    @Override
    public T removeFirst() {
        if (size == 0) {
            return null;
        }
        T result = data[front];
        data[front] = null;
        front = increment(front, data.length);
        size--;
        if (needsDownsize()) {
            resize(data.length / 2);
        }
        return result;
    }

    @Override
    public T removeLast() {
        if (size == 0) {
            return null;
        }
        back = decrement(back, data.length);
        T result = data[back];
        data[back] = null;
        size--;
        if (needsDownsize()) {
            resize(data.length / 2);
        }
        return result;
    }

    @Override
    public T get(int index) {
        if (index < 0 || index >= size) {
            return null;
        }
        int arrayIndex = (front + index) % data.length;
        return data[arrayIndex];
    }

    @Override
    public int size() {
        return size;
    }

    private void resize(int capacity) {
        T[] newData = (T[]) new Object[capacity];
        for (int i = 0, j = front; i < size; i++, j = increment(j, data.length)) {
            newData[i] = data[j];
        }
        data = newData;
        front = 0;
        back = size;
    }

    private boolean needsDownsize() {
        return size > 0 && size == data.length / 4;
    }
}
