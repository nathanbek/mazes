package deques;

import org.junit.jupiter.api.Test;

public class ArrayDequeTests extends BaseDequeTests {
    @Override
    protected <T> Deque<T> createDeque() {
        return new ArrayDeque<>();
    }

    @Override
    protected <T> void checkInvariants(Deque<T> deque) {
        // do nothing
    }

    @Test
    void resize_whenAddingBeyondInitialCapacity_shouldResizeWithoutLosingElements() {
        Deque<Integer> deque = createDeque();
        for (int i = 0; i < 10; i++) {  // Assuming initial capacity is less than 10
            deque.addLast(i);
        }
        assertThat(deque.size()).isEqualTo(10);
        for (int i = 0; i < 10; i++) {
            assertThat(deque.get(i)).isEqualTo(i);
        }
    }

    @Test
    void resize_whenRemovingElements_shouldDownsizeCorrectly() {
        Deque<Integer> deque = createDeque();
        for (int i = 0; i < 16; i++) {
            deque.addLast(i);
        }
        for (int i = 0; i < 12; i++) { // Remove elements to trigger downsizing
            deque.removeFirst();
        }
        assertThat(deque.size()).isEqualTo(4);
        for (int i = 0; i < 4; i++) {
            assertThat(deque.get(i)).isEqualTo(12 + i);
        }
    }

    @Test
    void addFirstAndAddLast_whenAddingAlternately_shouldMaintainCorrectOrder() {
        Deque<Integer> deque = createDeque();
        for (int i = 0; i < 5; i++) {
            deque.addFirst(i);
            deque.addLast(-i);
        }
        assertThat(deque.size()).isEqualTo(10);
        for (int i = 0; i < 5; i++) {
            assertThat(deque.get(i)).isEqualTo(4 - i);
            assertThat(deque.get(9 - i)).isEqualTo(-4 + i);
        }
    }

    @Test
    void removeOperations_whenDequeIsEmpty_shouldReturnNull() {
        Deque<Integer> deque = createDeque();
        assertThat(deque.removeFirst()).isNull();
        assertThat(deque.removeLast()).isNull();
    }

    // Additional tests for corner cases, efficiency, etc. can be added here
}
