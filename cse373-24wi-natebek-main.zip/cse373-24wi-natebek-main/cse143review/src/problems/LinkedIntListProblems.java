package problems;

import datastructures.LinkedIntList;
// Checkstyle will complain that this is an unused import until you use it in your code.
import datastructures.LinkedIntList.ListNode;

/**
 * See the spec on the website for example behavior.
 *
 * REMEMBER THE FOLLOWING RESTRICTIONS:
 * - do not call any methods on the `LinkedIntList` objects.
 * - do not construct new `ListNode` objects for `reverse3` or `firstToLast`
 *      (though you may have as many `ListNode` variables as you like).
 * - do not construct any external data structures such as arrays, queues, lists, etc.
 * - do not mutate the `data` field of any node; instead, change the list only by modifying
 *      links between nodes.
 */

public class LinkedIntListProblems {

    /**
     * Reverses the 3 elements in the `LinkedIntList` (assume there are exactly 3 elements).
     */
    public static void reverse3(LinkedIntList list) {
        ListNode first = list.front;
        ListNode second = first.next;
        ListNode third = second.next;


        second.next = first;
        first.next = third;

        list.front = second;
    }


    /**
     * Moves the first element of the input list to the back of the list.
     */
    public static void firstToLast(LinkedIntList list) {
        if (list.front != null && list.front.next != null) {
            ListNode firstNode = list.front;
            list.front = firstNode.next;
            firstNode.next = null;

            ListNode current = list.front;
            while (current.next != null) {
                current = current.next;
            }
            current.next = firstNode;
        }
    }

    /**
     * Returns a list consisting of the integers of a followed by the integers
     * of n. Does not modify items of A or B.
     */
    public static LinkedIntList concatenate(LinkedIntList a, LinkedIntList b) {
        LinkedIntList result = new LinkedIntList();

        ListNode current = result.front;

        ListNode aCurrent = a.front;
        while (aCurrent != null) {
            if (current == null) {
                result.front = new ListNode(aCurrent.data);
                current = result.front;
            } else {
                current.next = new ListNode(aCurrent.data);
                current = current.next;
            }
            aCurrent = aCurrent.next;
        }
        ListNode bCurrent = b.front;
        while (bCurrent != null) {
            if (current == null) {
                result.front = new ListNode(bCurrent.data);
                current = result.front;
            } else {
                current.next = new ListNode(bCurrent.data);
                current = current.next;
            }
            bCurrent = bCurrent.next;
        }

        return result;

    }
}
