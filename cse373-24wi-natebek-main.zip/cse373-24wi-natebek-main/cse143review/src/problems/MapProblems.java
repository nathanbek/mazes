package problems;

import java.util.Map;
import java.util.HashMap;
import java.util.List;


/**
 * See the spec on the website for example behavior.
 */
public class MapProblems {

    /**
     * Returns true if any string appears at least 3 times in the given list; false otherwise.
     */
    public static boolean contains3(List<String> list) {
        Map<String, Integer> map = new HashMap<>();

        for (String item : list) {
            if (map.containsKey(item)) {
                int count = map.get(item);
                map.put(item, count + 1);
            } else {
                map.put(item, 1);
            }
        }

        for (String key : map.keySet()) {
            if (map.get(key) >= 3) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns a map containing the intersection of the two input maps.
     * A key-value pair exists in the output iff the same key-value pair exists in both input maps.
     */
    public static Map<String, Integer> intersect(Map<String, Integer> m1, Map<String, Integer> m2) {
        Map<String, Integer> map = new HashMap<>();
        for (String key : m1.keySet()) {
            if (m2.containsKey(key) && m1.get(key).equals(m2.get(key))) {
                map.put(key, m1.get(key));
            }
        }


        return map;
    }
}
